#!/usr/bin/env python
 # -*- coding: utf-8 -*-
from __future__ import unicode_literals, division, absolute_import, print_function

try:
    from sigil_bs4 import BeautifulSoup
except:
    from bs4 import BeautifulSoup

import sys, os, urllib, os.path, time
PY2 = sys.version_info[0] == 2
    
if PY2:
    from urlparse import urlparse
else:
    from urllib.parse import urlparse

# required for some websites
user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.7) Gecko/2009021910 Firefox/3.0.7'
headers = {'User-Agent': user_agent} 
  
# get home folder location & current date/time
home = os.path.expanduser('~')
today = time.strftime("%Y%m%d-%H%M%S")

# define log file name
if os.path.isdir(os.path.join(home, 'Desktop')):
    log_file_name = os.path.join(home, 'Desktop', 'URLChecker_' + today +'.log')
else:
    log_file_name = os.path.join(home, 'URLChecker_' + today +'.log')

# get the line number
def getlinenumber(html, text):
    lines = html.splitlines()
    linums = []
    for index, line in enumerate(lines):
        if text in line:
            linums.append(index +1)
    return linums

# main routine
def run(bk):
    log_file = ''
    BrokenURLs = False
    # get all files in the spine
    for (html_id, linear) in bk.getspine():
        mime = bk.id_to_mime(html_id)
        
        # process only html files
        if mime == 'application/xhtml+xml':
            filename = os.path.basename(bk.id_to_href(html_id))
            
            print('\nProcessing ' + filename + '...\n')
            log_file += '\nProcessing ' + filename + '...\n'
            html = bk.readfile(html_id)
            
            # load html code into BeautifulSoup
            soup = BeautifulSoup(html, 'html.parser')
            
            # find all links
            CheckedURLs = []
            for link in soup.find_all('a'):
                href = link.get('href')

                # check only hrefs
                if href != None:
                
                    # ignore sites that have already been checked and non-URLs
                    if href.startswith('http') and urlparse(href).netloc != '' and href not in CheckedURLs:
                    
                    # try to connect to the site 
                        try:
                            if PY2:
                                response = urllib.urlopen(href)
                            else:
                                request = urllib.request.Request(href, None, headers)
                                response = urllib.request.urlopen(request)
                            print(href + ': OK')
                            log_file += href + ': OK\n'
                        except:
                            BrokenURLs = True
                            print(href + ' >>> Broken link! <<<')
                            log_file += href + ' >>> Broken link! <<<\n'
                            linenumbers = getlinenumber(html, href)
                            for linenumber in linenumbers:
                                bk.add_result('error', filename, linenumber, 'Broken link found: ' + href)
                        
                        # add URL to list of checked URLs
                        CheckedURLs.append(href)
                    else:
                        # add non-URLs to log
                        log_file += href + ': NOT CHECKED\n'

    # write log file
    open(log_file_name,'w').write(log_file)
    print('Log file writen to: ' + log_file_name)
    print('\nDone.\n\nPlease click OK to close the Plugin Runner window.')
    
    return 0


def main():
    print('I reached main when I should not have\n')
    return -1

if __name__ == "__main__":
    sys.exit(main())
