#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals, division, absolute_import, print_function

import os, os.path
from time import sleep
from updater import updateCheck
import options
            
import tkinter as tk
from tkinter import *
import  tkinter.filedialog as fdbox
import tkinter.messagebox as mbox 
from tkinter import ttk 

def centeredWindow(self, w, h):
    # get screen width and height
    ws = self.winfo_screenwidth()
    hs = self.winfo_screenheight()
   
    # calculate x and y coordinates for the Tk window
    x = (ws/2) - (w/2)
    y = ((hs/2) - (h/2) - 75)
    return(self.geometry('%dx%d+%d+%d' % (w, h, x, y)))
    
class UserOptions(tk.Frame):

    def __init__(self, parent):
        tk.Frame.__init__(self, parent, background='#E0E0E0')
        self.parent = parent
        centeredWindow(self.parent, 445, 148)
        parent.minsize(200, 50)
        parent.maxsize(700, 450)
        self.parent.protocol("WM_DELETE_WINDOW", self.onCancel)
        self.setup_UI()
       
    def setup_UI(self):
    
        self.labelf1 = LabelFrame(self, text='User Option', 
                        bg     = '#E0E0E0', 
                        font  = ('Helvetica', 10),                        
                        relief = RIDGE
                        )
        self.labelf1.pack(side=TOP, fill=BOTH, expand=True, ipady=27, pady=3, padx=3)
        
        InfoLabel = Label(self.labelf1, 
                        text   = "Do you want to convert all the shorthand 'margin' and \n" + \
                                 "'padding' properties to their long forms?", 
                                 
                        justify=LEFT,                                 
                        bg     = '#E0E0E0', 
                        font     = ('Helvetica', 10),
                        #wraplength= 300,
                        anchor = S
                        )
        InfoLabel.grid(column=1, sticky=W, row=0, padx=45, pady=15)
        
        styler = ttk.Style()
        styler.configure('New.TButton', font=('Helvetica', 10), background='#E0E0E0', width=10, relief=FLAT) 
        NoButton = ttk.Button(self.labelf1, 
                        text    = "No", 
                        style   = 'New.TButton', 
                        command = self.onNo
                        ).grid(row=1, column=1, sticky=E, pady=10)                
        
        styler.configure('New.TButton', font=('Helvetica', 10), background='#E0E0E0', width=10, relief=FLAT) 
        NoButton = ttk.Button(self.labelf1, 
                        text    = "Yes", 
                        style   = 'New.TButton', 
                        command = self.onYes
                        ).grid(row=1, column=1, sticky=E, padx=85, pady=10)
                        
        #**** Create the statusbar *****#
        self.status = Label(self.labelf1, text=" ",
                        relief = FLAT,
                        font   = ('Helvetica', 10),
                        bg     = '#E0E0E0',
                        fg     = '#0000FF',
                        anchor = W
                        )
        self.status.grid(row=2, column=1, sticky=W, padx=5)
        
        # show new plugin version msg if available
        if options.NEW_PLUGIN_VERSION:
            centeredWindow(self.parent, 430, 163)   
            self.status.config(text=options.MSG_NEW_VERSION_AVAILABLE)         
        
        self.grab_set()
        
        
    def onYes(self):
        options.CONVERT_TO_LONG_FORM = True
        self.parent.destroy()  
        
    def onNo(self):
        options.CONVERT_TO_LONG_FORM = False
        self.parent.destroy()  
        
    def onCancel(self):
        options.SYS_EXIT = True
        self.parent.destroy()          
  
                