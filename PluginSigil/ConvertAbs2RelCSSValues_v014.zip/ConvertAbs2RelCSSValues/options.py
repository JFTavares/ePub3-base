#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals, division, absolute_import, print_function

SYS_EXIT = False
MSG_NEW_VERSION_AVAILABLE = ''
NEW_PLUGIN_VERSION = False
CONVERT_TO_LONG_FORM = False


