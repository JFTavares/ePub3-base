#!/Python3/python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals, division, absolute_import, print_function

import os, os.path, sys, shutil, inspect, re
import options
from decimal import *  
import tkinter as tk
import tkinter.messagebox as mbox

try:
    from sigil_bs4 import BeautifulSoup, Comment
except:
    from bs4 import BeautifulSoup, Comment    

___all__=["processAllTasks", "copyCSSFiles2Dir", "writeFiles2CSS", "show_msgbox", "prettifyCSS", "convertAbs2RelCSSValues", "cleanExit", "prettifyCSS1", "prettifyCSS2", "convertMarginFormat", "convertPaddingFormat", "convert2EmValues"]

def processAllTasks(bk, wdir, s_ids, s_fnames):
    print('\n -- Processing automatic tasks...')
    print(' -- Convert absolute values to relative em values in the CSS')
    
    for file in s_fnames:
        file = os.path.join(wdir, file)
        convertMarginFormat(wdir, file)
        convertPaddingFormat(wdir, file)
        prettifyCSS1(wdir, file)
        convertAbs2RelCSSValues(wdir, file)
        prettifyCSS2(wdir, file)          
         
    # write css files back to epub         
    writeFiles2CSS(bk, wdir, s_ids, s_fnames)        
    return(0)
    
                
def copyCSSFiles2Dir(bk, wdir):
    s_ids = list()
    s_hrefs = list()
    s_fnames = list()
    for (i, h) in bk.css_iter():
        s_ids.append(i)
        s_hrefs.append(h)
        s_fnames.append(os.path.basename(h))
        
    j = 0    
    for sid in s_ids:
        file = os.path.join(wdir, s_fnames[j])
        print(' -- Write to work dir...' + file)
        with open(file, 'wt', encoding='utf-8') as outfp: 
            data = bk.readfile(sid)
            html = BeautifulSoup(data, 'html.parser')
            outfp.writelines(str(html))                
            j = j + 1     
            
    return(s_ids, s_fnames) 

def writeFiles2CSS(bk, wdir, ids, s_fnames): 
    # no css files with imported html docs
    count = len(s_fnames)
    if count == 0: 
        return(0) 
        
    i = 0
    print(' ')  
    for file in s_fnames:
        if os.path.getsize(os.path.join(wdir, file)) < 5:
            continue        
        #prettifyCSS(wdir, file) 
        print(' -- Write to epub CSS...' + str(file))        
        with open(os.path.join(wdir, file), 'rt', encoding='utf-8') as fp:              # input file is epub 
            data = fp.read()           
            bk.writefile(ids[i], data)
            i = i + 1
                        
    return(0)                  
    
def show_msgbox(title, msg, msgtype='info'):
    """ For general information, warnings and errors
    """
    localRoot = tk.Tk()
    localRoot.withdraw()
    localRoot.option_add('*font', 'Helvetica -12')
    localRoot.quit()
    if msgtype == 'info':
        return(mbox.showinfo(title, msg))
    elif msgtype == 'warning':
        return(mbox.showwarning(title, msg))
    elif msgtype == 'error':
        return(mbox.showerror(title, msg))
            
        
def prettifyCSS(wdir, css):
    output = os.path.join(wdir, 'link_rel.html')
    outfp = open(output, 'wt', encoding='utf-8')
    with open(css, 'rt', encoding='utf8') as infp:      
        for line in infp:
            if re.match(r'^\s*$', line):
                continue 
            if line.strip() == '':
                continue   
            if line.strip() == ';':
                continue 
            if '{' in line:
                line = line.replace(' ', '')
                line = line.replace('{', '  {')                
            outfp.write(line.strip() + '\n')                
    
    outfp.close()
    os.remove(css)
    os.rename(output, css)
    return(0)  
    
def convertAbs2RelCSSValues(wdir, file):
    """ Converts absolute to relative values in the CSS 
    """
    print(' -- Convert absolute to relative values in the CSS')                
    temp = wdir + os.sep + 'absolute.css'      
    outfp = open(temp, 'wt', encoding=('utf-8'))
    with open(file, 'rt', encoding=('utf-8')) as infp:
        
        for line in infp:
        
                if 'border:' in line or line.strip().startswith('size'):
                    outfp.write(line)
                    continue     
                
                #remove empty lines
                if line.strip() == '':
                    continue
                    
                if line.strip() == ';':
                    continue        

                # convert the shorthand margin and padding forms to em values in place    
                if 'margin:' in line or 'padding:' in line:
                    if 'em' in line or '%' in line or 'px' in line:
                        outfp.write(line)
                        continue
                    else:
                        property_str, value_str = line.split(':')
                        value_str = value_str.strip().replace(';', '')
                        value_list = value_str.split(' ')
                        if value_str.strip().replace(' ', '').isdigit() or \
                            'em' in value_str or 'px' in value_str or '%' in value_str:
                            outfp.write(line)
                            continue
                        else:    
                            em_val_str = convert2EmValues(value_list)
                            line = property_str + em_val_str
                            outfp.write(line)
                            continue
                                    
                    
                # convert 'in' to relative 'em' values
                if 'in;' in line:
                    if ' 0in;' in line  or ' 0.0in;' in line or ' 0.00in' in line or ' 0.000in' in line or ' 0.0000in' in line:
                        line = line.replace(' 0in;', ' 0;')
                        line = line.replace(' 0.0in;', ' 0;')
                        line = line.replace(' 0.00in;', ' 0;')
                        line = line.replace(' 0.000in;', ' 0;')
                        line = line.replace(' 0.0000in;', ' 0;')
                        outfp.write(line)
                        continue
                                        
                    else:
                        line = line.strip().replace('{', '')   
                        if line.startswith('.'):
                            line = '0' + line
                        out_em, s_line = line.split(':')
                        inch = s_line.replace('in;', '')
                        inchf = float(inch)                                   
                        getcontext().prec = 3                 
                        em = Decimal(inchf) * Decimal(6.022)
                        em = Decimal(em).normalize()
                        if '.0' in str(em):
                            em_str = out_em + ': ' + str(int(round(em))) + 'em;\n'
                        else:                             
                            em_str = out_em + ': ' + str(em) + 'em;\n'
                        outfp.write(em_str)
                        continue
                        
                # convert 'pt' to relative 'em' values        
                elif 'pt;' in line:
                    if ' 0pt;' in line or ' 0.0pt' in line or ' 0.00pt' in line or ' 0.000pt' in line or ' 0.0000pt' in line:
                        line = line.replace(' 0pt;', ' 0;')
                        line = line.replace(' 0.0pt;', ' 0;')
                        line = line.replace(' 0.00pt;', ' 0;')
                        line = line.replace(' 0.000pt;', ' 0;')
                        line = line.replace(' 0.0000pt;', ' 0;')
                        outfp.write(line)
                        continue
                         
                    else:    
                        line = line.strip().replace('{', '')                   
                        if line.startswith('.'):
                            line = '0' + line          
                        out_em, s_line = line.split(':')
                        point = s_line.replace('pt;', '')
                        points = float(point)               
                        getcontext().prec = 3                        
                        em = Decimal(points) / Decimal(12.0)
                        em = Decimal(em).normalize()
                        if '.0' in str(em):
                            em_str = out_em + ': ' + str(int(round(em))) + 'em;\n'
                        else:                         
                            em_str = out_em + ': ' + str(em) + 'em;\n'
                        outfp.write(em_str)
                        continue
                        
                # convert 'cm' to to relative 'em' values         
                elif 'cm;' in line:
                    if ' 0cm;' in line or ' 0.0cm' in line or ' 0.00cm' in line or ' 0.000cm' in line or ' 0.0000cm' in line:
                        line = line.replace(' 0cm;', ' 0;')
                        line = line.replace(' 0.0cm;', ' 0;')
                        line = line.replace(' 0.00cm;', ' 0;')
                        line = line.replace(' 0.000cm;', ' 0;')
                        line = line.replace(' 0.0000cm;', ' 0;')
                        outfp.write(line)
                        continue

                    else:    
                        line = line.strip().replace('{', '')                   
                        if line.startswith('.'):
                            line = '0' + line          
                        out_em, s_line = line.split(':')
                        cms = s_line.replace('cm;', '')
                        new_cms = float(cms)
                        getcontext().prec = 3                                       
                        em = Decimal(new_cms) * Decimal(2.3710)
                        em = Decimal(em).normalize()
                        if '.0' in str(em):
                            em_str = out_em + ': ' + str(int(round(em))) + 'em;\n'
                        else:  
                            em_str = out_em + ': ' + str(em) + 'em;\n'
                        outfp.write(em_str)
                        continue
                        
                # convert 'mm' to relative 'em' values         
                elif 'mm;' in line:
                   
                    if ' 0mm;' in line or ' 0.0mm' in line or ' 0.00mm' in line or ' 0.000mm' in line or ' 0.0000mm' in line:
                        line = line.replace(' 0mm;', ' 0;')
                        line = line.replace(' 0.0mm;', ' 0;')
                        line = line.replace(' 0.00mm;', ' 0;')
                        line = line.replace(' 0.000mm;', ' 0;')
                        line = line.replace(' 0.0000mm;', ' 0;')
                        outfp.write(line)
                        continue

                    else:
                        line = line.strip().replace('{', '')                   
                        if line.startswith('.'):
                            line = '0' + line          
                        out_em, s_line = line.split(':')
                        mms = s_line.replace('mm;', '')
                        new_mms = float(mms)               
                        getcontext().prec = 3
                        em = Decimal(new_mms) * Decimal(0.2371)
                        em = Decimal(em).normalize()
                        if '.0' in str(em):
                            em_str = out_em + ': ' + str(int(round(em))) + 'em;\n'
                        else:  
                            em_str = out_em + ': ' + str(em) + 'em;\n'
                        outfp.write(em_str)
                        continue    
                                
                # convert 'pc' to to relative 'em' values         
                elif 'pc;' in line:
                    line = line.replace('pc;', 'em;')
                    outfp.write(line)
                    continue

                else:
                    outfp.write(line)    
             
    outfp.close()
    os.remove(file)
    os.rename(temp, file)    
    return(0)        
   
    
    # convert all 0.0000em values to 0em
    temp = wdir + os.sep + 'absolute.tmp'      
    outfp = open(temp, 'wt', encoding=('utf-8'))
    with open(file, 'rt', encoding=('utf-8')) as infp: 
        for line in infp:
            if '0.0000em;' in line:
                line = line.replace('0.0000em;', '0;') 
                outfp.write(line)
                continue
            else:
                outfp.write(line) 
    outfp.close()
    os.remove(file)
    os.rename(temp, file)     
            
    prettifyCSS2(wdir, file)    
    return(0)
    
def cleanExit(wdir):
    shutil.rmtree(wdir, ignore_errors=True)
    return(0)
 
def prettifyCSS1(wdir, css):
    output = os.path.join(wdir, 'reformat1.html')
    outfp = open(output, 'wt', encoding='utf-8')
    with open(css, 'rt', encoding='utf8') as infp:      
        for line in infp:
           
            if ':' in line and ': ' not in line and not line.strip().startswith('a:'):
                line = line.replace(':', ': ')         
           
           # format attribute from line to stacked format
            if '{' in line and ':' in line and '}' in line:
                line = line.replace('{', '  {\n')
                line = line.replace(';', ';\n')
                line = line.replace('}', '\n}\n')                
            outfp.write(line.strip() +'\n')
    
    outfp.close()
    os.remove(css)
    os.rename(output, css)    
    
    output = os.path.join(wdir, 'reformat2.html')
    outfp = open(output, 'wt', encoding='utf-8')
    with open(css, 'rt', encoding='utf8') as infp:      
        for line in infp:
            if line.strip() == '':
                continue
        
           # ensure all style properties end in ';'
            if '{' not in line and '}' not in line and ',' not in line:
                if not line.strip().endswith(';'):
                    line = line + ';\n'                
            outfp.write(line.strip() + '\n')
    
    outfp.close()
    os.remove(css)
    os.rename(output, css)    
    return(0)
    
 
def prettifyCSS2(wdir, css):
    output = os.path.join(wdir, 'link_rel.html')
    outfp = open(output, 'wt', encoding='utf-8')
    with open(css, 'rt', encoding='utf8') as infp:      
        for line in infp:
            if 'font-family:' not in line and '{' not in line and 'src:' not in line:
                line = line.lower()    
        
            if re.match(r'^\s*$', line):
                continue 
            
            if line.strip() == '':
                continue   
            
            if line.strip() == ';':
                continue        
        
            outfp.write(line)
    
    outfp.close()
    os.remove(css)
    os.rename(output, css)    
    return(0)
    
def convertMarginFormat(wdir, file):

    if options.CONVERT_TO_LONG_FORM == False:
        return(0)
        
    # change and reformat all short form margin declarations to long form.
    temp = wdir + os.sep + 'margin.tmp'      
    outfp = open(temp, 'wt', encoding=('utf-8'))
    with open(file, 'rt', encoding=('utf-8')) as infp:
        for line in infp: 
            if line.strip() == '':
                continue
                
            if line.strip() == ';':
                continue            
                
            if 'margin: 0 auto' in line or 'margin:0 auto' in line:
                outfp.write(line)
                continue
                
            if 'margin:' in line:
                line = line.replace(';', '')
                line = line.split(':')[1]
                line = line.strip()
                liner = line.split(' ')
                # Example: 'margin 1.5pt 0.5pt 2.0pt 1pt;'
                if len(liner) == 4:
                    i=0
                    pos = ['top', 'right', 'bottom', 'left']
                    for m in liner:
                        outfp.write('margin-' + pos[i] + ': ' + m + ';\n')
                        i += 1
                # Example: 'margin: 1.5pt 1pt 0pt;'        
                elif len(liner) == 3:
                    data = 'margin-top: ' +  liner[0] + ';\n'
                    data += 'margin-left: ' +  liner[1] + ';\n'
                    data += 'margin-right: ' + liner[1] + ';\n'
                    data += 'margin-bottom: ' + liner[2] + ';\n'
                    outfp.write(data)        
                # Example: 'margin: 1.5pt 0pt;'        
                elif len(liner) == 2:
                    data = 'margin-top: ' +  liner[0] + ';\n'
                    data += 'margin-bottom: ' +  liner[0] + ';\n'
                    data += 'margin-right: ' + liner[1] + ';\n'
                    data += 'margin-left: ' + liner[1] + ';\n'
                    outfp.write(data)
                # Example 'margin: 4pt;'
                elif len(liner) == 1:
                    data = 'margin-top: ' +  liner[0] + ';\n'
                    data += 'margin-bottom: ' +  liner[0] + ';\n'
                    data += 'margin-right: ' + liner[0] + ';\n'
                    data += 'margin-left: ' + liner[0] + ';\n'
                    outfp.write(data)
            else:
                outfp.write(line)
                
    outfp.close()
    os.remove(file)
    os.rename(temp, file)     
    return(0)
    
def convertPaddingFormat(wdir, file):
    
    if options.CONVERT_TO_LONG_FORM == False:
        return(0)
        
    # change and reformat all short form margin declarations to long form.
    temp = wdir + os.sep + 'padding.tmp'      
    outfp = open(temp, 'wt', encoding=('utf-8'))
    with open(file, 'rt', encoding=('utf-8')) as infp:
        for line in infp: 
            if line.strip() == '':
                continue
                
            if line.strip() == ';':
                continue            
    
            if 'padding:' in line:
                    line = line.replace(';', '')
                    line = line.split(':')[1]
                    line = line.strip()
                    liner = line.split(' ')
                    if len(liner) == 4:
                        j=0
                        pos = ['top', 'right', 'bottom', 'left']
                        for p in liner:  
                            outfp.write('padding-' + pos[j] + ': ' + p + ';\n')
                            j += 1
                    # Example: 'margin: 1.5pt 1pt 0pt;'        
                    elif len(liner) == 3:
                        data = 'padding-top: ' +  liner[0] + ';\n'
                        data += 'padding-left: ' +  liner[1] + ';\n'
                        data += 'padding-right: ' + liner[1] + ';\n'
                        data += 'pdding-bottom: ' + liner[2] + ';\n'
                        outfp.write(data)                
                    # Example: 'padding: 1.5pt 0pt;'                     
                    elif len(liner) == 2:
                        data = 'padding-top: ' +  liner[0] + ';\n'
                        data += 'padding-bottom: ' +  liner[0] + ';\n'
                        data += 'padding-right: ' + liner[1] + ';\n'
                        data += 'padding-left: ' + liner[1] + ';\n'
                        outfp.write(data)
                    # Example 'padding: 4pt;'
                    elif len(liner) == 1:
                        data = 'padding-top: ' +  liner[0] + ';\n'
                        data += 'padding-bottom: ' +  liner[0] + ';\n'
                        data += 'padding-right: ' + liner[0] + ';\n'
                        data += 'padding-left: ' + liner[0] + ';\n'
                        outfp.write(data)        
            else:
                outfp.write(line)        
            
    outfp.close()
    os.remove(file)
    os.rename(temp, file)    
    return(0)    
    
def convert2EmValues(values):
    new_em_values = []
    for value in values: 
        if value == '0' or value == '0;':
            new_em_values.append(value)
  
        # convert 'pt' values to 'em' 
        elif value.endswith('pt'):
            value = value.replace('pt', '') 
            n_value = float(value)
            print('\n >>> float value...' + str(n_value))
            if n_value == 0:
                value = '0em'
                new_em_values.append(value)
                continue
            getcontext().prec = 3
            n_value = Decimal(value)/Decimal(12.0)
            n_value = Decimal(n_value).normalize() 
            if '.0' in str(n_value):
                strval = str(int(round(n_value))) + 'em'
            else:                                         
                strval = str(n_value) + 'em'
            print(' >>> decimal value...' + strval + '\n')
            new_em_values.append(strval)

        # convert 'in' values to 'em'     
        elif value.endswith('in'):
            value = value.replace('in', '') 
            n_value = float(value)
            if n_value == 0:
                value = '0em'    
                new_em_values.append(value)
                continue
            n_value = Decimal(n_value) * Decimal(6.0225)
            n_value = Decimal(n_value).normalize()
            if '.0' in str(n_value):
                strval = str(int(round(n_value))) + 'em'
            else:                  
                strval = str(n_value) + 'em'
            new_em_values.append(strval)
           
        # convert 'cm' values to 'em'    
        elif value.endswith('cm'):
            value = value.replace('cm', '') 
            n_value = float(value)
            if n_value == 0:
                value = '0em'
                new_em_values.append(value)
                continue
            getcontext().prec = 3
            n_value = Decimal(n_value) * Decimal(2.3710)
            n_value = Decimal(n_value).normalize()
            if '.0' in str(n_value):
                strval = str(int(round(n_value))) + 'em'
            else:      
                strval = str(n_value) + 'em'
            new_em_values.append(strval)

        # convert 'mm' values to 'em'       
        elif value.endswith('mm'):
            value = value.replace('mm', '') 
            n_value = float(value)
            if n_value == 0:
                value = '0em'
                new_em_values.append(value)
                continue
            getcontext().prec = 3
            n_value = Decimal(n_value) * Decimal(0.2371)
            n_value = Decimal(n_value).normalize()
            if '.0' in str(n_value):
                strval = str(int(round(n_value))) + 'em'
            else:                  
                strval = str(n_value) + 'em'
            new_em_values.append(strval)
            
        # convert 'pc' values to 'em'      
        elif value.endswith('pc'):
            value = value.replace('pc', 'em') 
            new_em_values.append(value)

    # convert the list back to a formatted string        
    new_ems = ",".join(new_em_values)
    new_ems = new_ems.replace(',', ' ')
    new_ems = ': ' + new_ems.strip() + ';\n'
 
    return(new_ems) 
       
    
            
        
        
             
        
            