#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals, division, absolute_import, print_function


SYS_EXIT = False
MSG_NEW_VERSION_AVAILABLE = ''
NEW_PLUGIN_VERSION = False
SET_QUERY_CSS = ''
CSS_FNAMES = []
SET_CSS_FNAME = ''
BASE_WIDTH_VALUE = '630'

CONVERT_ABSOLUTE_VALUES = False
CONVERT_MARGIN_VALUES = False
CONVERT_PADDING_VALUES = False

