#!/Python3/python
# -*- coding: utf-8 -*-

#
# Helps to gather all function names from  
# a py file -- used to define the __All__ 
# array for the import call.
#
import os, re, sys, shutil

    
file = input("\nInput py file: \n\n")


outfile = os.getcwd() + os.sep + 'all_list.txt'
outfp = open(outfile, 'w+', encoding='utf-8')

file = os.getcwd() + os.sep + file
with open(file, 'rt', encoding='utf-8') as fp:
    outfp.write('\n' + os.path.basename(file) + '\n\n')
    outfp.write('__all__=[')
    for line in fp:
        if 'def ' in line or \
            'class ' in line and \
            '):' in line:
            # get and format the function name
            p = re.compile('\(.*?\)')
            line = p.sub('', line)
            line = line.replace('def ', '')
            line = line.replace('class ','')
            line = line.replace(':', '')
            line = line.replace('\n', '')
            line = line.replace(' ', '')
            l = '"' + line + '", '
            print(l)                
            outfp.write(l)    
    
outfp.write(']\n')
outfp.close()       

# correct last entry format...
tempf = 'temp01.tmp'
out2 = open(tempf, 'wt', encoding='utf-8')
with open(outfile, 'rt', encoding='utf-8') as outfp:                             
    for line in outfp:
        if ', ]' in line:
            line = line.replace(', ]', ']')
            out2.write(line)
        else:
            out2.write(line)
        
out2.close()
shutil.copyfile(tempf, outfile)
os.remove(tempf)

os._exit(0)




 














